# Prompt principal para o Codex — Portabilidade do RESET EXPLODE para Linux

> Cole o texto a seguir no Codex com uma cópia/fork do repositório `https://github.com/GustavoReset/ResetExplode` aberto como workspace. Esta é uma instrução de engenharia para execução por etapas, não uma autorização para executar todos os benchmarks de carga ou alterar o sistema operacional.

## Papel e contexto

Atue como engenheiro sênior de C#/.NET, Avalonia UI, sistemas Linux, benchmarks e arquitetura multiplataforma. Trabalhe no repositório REAL aberto neste workspace: `https://github.com/GustavoReset/ResetExplode` (preferencialmente um fork em branch de desenvolvimento). O objetivo é produzir um PORT NATIVO, real, testável e sustentável para Linux, reaproveitando o máximo possível do código original, sem danificar a edição Windows. NÃO substitua a aplicação por um protótipo Python, WebView ou por outra linguagem. Rust somente poderá ser considerado depois de medições e justificativa técnica.

O repositório atualmente é uma aplicação WPF para `net8.0-windows`. O `.csproj` original usa `UseWPF`, LibreHardwareMonitor, System.Management/WMI, TraceEvent, Vortice Direct3D 11/12/DXC e código específico do Windows. O README declara licença MIT e informa que o autor não aceita pull requests atualmente: trabalhe num fork e preserve autoria, avisos de copyright e licenças de terceiros. Não assuma que todos os assets, drivers e SDKs binários podem ser redistribuídos; verifique-os um a um.

**Objetivo de produto:** experiência Linux com interface Avalonia, identificação e monitoramento de hardware, relatórios e benchmarks reais progressivamente portados. O foco inicial é Linux desktop x86_64, com suporte por adaptadores e erros claros a outras plataformas. Preservar a possibilidade de compartilhar código e oferecer Windows + Linux no mesmo repositório.

## Restrições inegociáveis

1. Comece lendo TODOS os arquivos relevantes do repositório, não apenas README, e produza inventário antes de migrar. Salve o SHA/commit base. Não trate o nome de um arquivo como prova de compatibilidade: examine implementação e dependências transitivas.
2. Nunca apague, reescreva em massa, renomeie de forma destrutiva ou quebre a aplicação WPF original. Trabalhe em uma branch nova. Não altere o workflow de releases original para publicar builds Linux como se fossem oficiais. Não faça push, abra PR, crie release nem envie telemetria sem autorização explícita.
3. Não execute `sudo`, instaladores de drivers, scripts baixados da internet, overclock, alteração de clock/voltagem, operações de escrita em dispositivos de bloco, limpeza de arquivos de usuário ou modificações de boot/systemd/udev. Não invoque stress tests ou benchmarks pesados automaticamente durante o desenvolvimento ou nos testes de CI.
4. Discos: qualquer benchmark deve trabalhar EXCLUSIVAMENTE com arquivos temporários criados em diretórios autorizados, com verificação de espaço disponível, limites configuráveis, cancelamento, tratamento de erros, limpeza em `finally` e aviso sobre cache. Nunca execute testes em `/dev/sd*`, `/dev/nvme*` nem escreva diretamente em partições.
5. Informações de `/proc`, `/sys`, APIs e programas do sistema são dados NÃO CONFIÁVEIS: valide formato/tamanho, use timeouts, evite shell injection, preferindo APIs nativas ou `ProcessStartInfo.ArgumentList`. Sensores inexistentes retornam estado **indisponível**, não `0°C` inventado.
6. Mantenha separação de resultados entre benchmarks novos/alterados e pontuações oficiais. Nunca alegue comparabilidade sem equivalência de workload, parâmetros, medição e validação. Inclua versão do algoritmo, sistema operacional, runtime e condições de medição em cada relatório.
7. Toda ação que toque no sistema deve seguir princípio de menor privilégio. Por padrão, a aplicação Linux deve funcionar sem root; recursos que exijam privilégios ficam desativados e documentados. Nenhum download/executável automático. Sem coleta ou upload remoto de dados por padrão.
8. Respeite `AGENTS.md` já existente. Proponha instruções adicionais de projeto quando necessário e não sobrescreva regras existentes. Verifique sempre dependências, licenças, manutenção e segurança.
9. Registre evidências reais de build/teste. Se uma verificação não puder ser realizada por falta de internet, SDK, display, hardware ou sistema Windows, marque `NÃO TESTADO` e dê comandos para reproduzi-la. Nunca invente resultados nem declare suporte a Wayland, NVIDIA, AMD ou Intel sem testes.
10. Faça mudanças pequenas, reversíveis, com testes. Priorize solução incremental compilável em vez de código extenso não funcional. Não migre GPU/overlay/otimização antes do núcleo mínimo funcionar.

## Arquivos concretos para analisar inicialmente

- `ResetExplode.csproj`, `README.md`, `LICENSE`, `.github/workflows/`, `App.xaml*`, `MainWindow.xaml*`, `Theme.xaml`.
- Núcleo do RESET BENCH CPU: `BenchRenderer.cs`; simulação de jogo CPU: `GameSimBench.cs`.
- Memória/discos: `MemoryBench.cs`, `DiskBench.cs`, `DiskHealth.cs`, `DriveMap.cs`.
- Hardware/sensores: `SystemInfoCollector.cs`, `GpuInfoCollector.cs`, `SensorMonitor.cs`, `Nvml.cs`, `BatteryInfo.cs`.
- Relatórios/rede: `ReportBuilder.cs`, `NetworkTest.cs`.
- Módulos GPU Windows: `GpuGameBench.cs`, `GpuRtBench.cs`, `GpuBurn.cs`, `Dxgi.cs`, `FrameMonitor.cs`, `OverlayMetrics.cs`.
- Serviços específicos de Windows: `DriverManager.cs`, `WindowsTweaks.cs`, `Optimizer.cs`, `StartupManager.cs`, `AppInstaller.cs`, `MakerDrivers.cs`, `UsbCleaner.cs`, `CorsairSdk.cs`.
- Integração, aplicativos e jogos: `LightBackends.cs`, `GameLibrary.cs`, `GameLauncher.cs`, `Vdf.cs` e arquivos parciais `MainWindow.*.cs`.

## Arquitetura-alvo (ajuste somente se a auditoria justificar)

Crie uma solução multiplataforma, preferencialmente:

```
src/
  ResetExplode.Contracts/          # DTOs, resultados, capacidades, interfaces, tipos comuns
  ResetExplode.Core/               # regras e workloads C# independentes do SO e da UI
  ResetExplode.Platform.Linux/     # /proc, /sys, sensores e serviços Linux
  ResetExplode.Platform.Windows/   # adaptadores para APIs Windows, conforme viável
  ResetExplode.Desktop/            # interface Avalonia + MVVM
  ResetExplode.Cli/                # diagnósticos CLI, testes sem display e JSON
tests/
  ResetExplode.Core.Tests/
  ResetExplode.Platform.Linux.Tests/
  ResetExplode.Integration.Tests/
docs/
  portabilidade-inventario.md
  arquitetura.md
  compatibilidade-linux.md
  benchmarks-metodologia.md
  roadmap-linux.md
  validacao.md
```

A estrutura é sugestão, não dogma; evite projetos vazios sem necessidade. Como o .NET 8 perde suporte em novembro de 2026, **avalie como padrão .NET 10 LTS para os novos executáveis Linux**. Se os contratos/núcleo compartilhados precisarem ser consumidos pelo aplicativo Windows ainda em `net8.0-windows`, esses projetos podem mirar `net8.0` temporariamente; documente a escolha e planeje a migração Windows para .NET 10. Nunca mude o TFM do projeto Windows original às cegas. Escolha uma versão estável de Avalonia verificada e compatível com SDK e runtime disponíveis. Adote MVVM e DI moderadamente, evitando abstrações artificiais.

**ATENÇÃO ao SDK-style C#:** `ResetExplode.csproj` está na raiz e usa inclusão implícita recursiva de `*.cs`; adicionar `src/**` e `tests/**` sob a raiz pode fazer o projeto WPF compilar arquivos dos projetos novos. Inspecione o comportamento de globbing e aplique exclusões explícitas `Compile Remove` (e recursos relevantes) no projeto original, ou outra solução mínima equivalente, antes de introduzir subprojetos. Confirme que a mudança não quebra o Windows.

Interfaces sugeridas (definir contratos mínimos reais, não implementar tudo por antecipação): `IHardwareInfoProvider`, `ISensorProvider`, `IBenchmarkRunner`, `IReportExporter`, `IPlatformCapabilities`. Separar coleta, unidades, modelos de domínio, apresentação, cancellation e operações de benchmark. Apresentar recurso indisponível com causa legível; não mascarar erros com dados fictícios.

## FASE 0 — Auditoria e especificação (executar primeiro)

1. Registre branch, SHA, versão do .NET, distribuição/kernel (se Linux), disponibilidade de display e dependências. Avalie `.NET 10` LTS para novos projetos versus `.NET 8` legado (fim de suporte em novembro de 2026). Leia README, manifesto de licença, .csproj, workflow CI e todas as classes relevantes; identifique referências entre arquivos e tipos.
2. Produza em `docs/portabilidade-inventario.md` uma matriz POR FUNCIONALIDADE: módulo, arquivos, APIs/assemblies envolvidos, capacidade de reutilização (direto / refatorar / reimplementar / indisponível), riscos, prioridade, estratégia Linux, estratégia Windows e critérios de teste.
3. Mapeie lógica acoplada a WPF, WMI, Registry, ETW, DirectX/DXGI, Windows Storage, winget, drivers seriais, PawnIO, SDK Corsair, NVML, OpenRGB. Avalie `RuntimeInformation.IsOSPlatform` apenas como decisão na composition root/adapters, e não como milhares de condicionais espalhados.
4. Analise algoritmo, determinismo e pontuação do `BenchRenderer.cs` (RESET BENCH CPU). Compare com `GameSimBench.cs`, `MemoryBench.cs` e `DiskBench.cs`. Identifique exatamente o que é algoritmo puro, o que é dependente de UI e o que exige chamadas Windows.
5. Registre condições de concorrência/segurança, licenças de bibliotecas, origem dos assets, bibliotecas Linux alternativas e limitações. Não troque ou descontinue uma dependência sem motivo demonstrável.
6. Crie `docs/arquitetura.md` e `docs/roadmap-linux.md` com fases, critérios de aceite e riscos. Crie/atualize `AGENTS.md` de forma concisa e preservando conteúdo já existente.
7. Execute build/testes EXISTENTES quando tecnicamente possível. Não trate falha esperada de WPF no host Linux como regressão do código original; documente-a. Inspecione o `git diff` antes de avançar.

**Saída da Fase 0:** documentos coerentes e rastreáveis a arquivos/classes existentes, lista de bloqueios reais e plano arquitetural. Não descreva uma auditoria completa se arquivos não foram acessados.

## FASE 1 — Primeiro incremento funcional de Linux (executar nesta interação APÓS fase 0, se houver ferramentas/dependências disponíveis)

Objetivo: executar uma aplicação .NET Linux realmente compilável, com caminho completo da fonte de dados até UI + CLI, SEM rodar stress test nem depender de hardware proprietário.

1. Criar solução/estrutura mínima necessária e ajustar exclusão de globbing do `.csproj` da raiz.
2. Criar Contracts/Core com um `SystemInfo` neutro contendo SO/kernel, CPU (nome/núcleos lógicos), RAM (total/disponível) e discos (dispositivos/capacidades quando acessíveis), juntamente com origem/unidade e status de disponibilidade. Omitir identificadores sensíveis por padrão.
3. Implementar leitura Linux robusta por `/proc/cpuinfo`, `/proc/meminfo`, `/sys` e APIs .NET onde adequadas. Não inferir CPU/GPU/detalhes que não constem do sistema. Não assumir que `nvidia-smi`, `lspci`, `lsblk` ou `smartctl` estejam instalados; se usados como fallback, detecte presença e use timeout.
4. CLI: oferecer ao menos `info` e `capabilities` em saída legível e opcionalmente JSON (ex.: `dotnet run --project src/ResetExplode.Cli -- info --json`). Opção `--help`. Sem root.
5. Avalonia UI: criar janela mínima coerente com estética RESET EXPLODE (sem copiar assets sem conferir licença), dashboard com cards para CPU/RAM/SO/disco e estados de indisponibilidade, botão atualizar e ação exportar snapshot local. Não instalar dependências arbitrárias na máquina.
6. Relatório JSON offline contendo schema/version e fontes/limitações, com tratamento de caminho escolhido pelo usuário e sem uploads.
7. Testes automatizados para parse de arquivos `/proc`/`/sys` com fixtures e dados inválidos, formatos ausentes, locale, unidades, erros de permissão e capacidades indisponíveis. Build Core+Linux+CLI+Desktop em Linux; executar smoke test CLI e, somente se houver sessão gráfica apropriada, smoke test manual UI. Registrar comandos e saídas.
8. Agregar somente alterações necessárias à primeira vertical slice; TODOs devem mencionar condição de conclusão. Remover qualquer botão fictício, gráfico com métricas fabricadas ou benchmark stub que pareça funcional.

**Critérios de aceite Fase 1:** `dotnet build` dos novos projetos em host Linux; `dotnet test` passa para o que puder rodar; `dotnet run --project src/ResetExplode.Cli -- info` retorna informação factual/indisponível sem root; a aplicação Avalonia compila; com display configurado, janela exibe dados reais; projeto original não foi removido nem teve dependências Windows misturadas às libs portáveis. Se não houver display, reportar interface apenas compilada, não testada visualmente.

## FASE 2 — Portar o RESET BENCH CPU preservando algoritmo

- Estude `BenchRenderer.cs` e extraia renderizador, seed, workload, dimensões, threads, warmup, tempo, cancelamento e método de pontuação para Core sem acoplamento WPF. Não altere o cálculo para fazê-lo 'mais rápido' nem invente novas pontuações.
- Crie testes de determinismo para um workload REDUZIDO (golden output/hash e verificações numéricas) e testes de concorrência/cancelamento. Benchmark longo fica opt-in no aplicativo, não na CI.
- Documente se score Linux é ou não comparável ao Windows e por quê (JIT, arquitetura, afinidade, scheduler, potência, throttling e versão). Não use resultado do protótipo Python como score RESET BENCH.
- Depois, analise `GameSimBench.cs` e `MemoryBench.cs` com o mesmo rigor.

**Aceite:** workload original preservado ou diferença claramente versionada/documentada, cálculo reprodutível, sem dependência de UI ou WMI.

## FASE 3 — Sensores, saúde e diagnósticos de hardware

- Implemente adaptadores Linux de sensores disponíveis no kernel por `hwmon`, `thermal`, informações de energia/bateria e armazenamento; monitore alterações de hardware e trate hardware virtualizado/container.
- GPU: detectar AMD/Intel/NVIDIA por DRM/PCI e, opcionalmente, bibliotecas/APIs vendor devidamente verificadas; temperatura/carga/VRAM apenas quando efetivamente disponibilizadas.
- Disco/S.M.A.R.T.: use abstrações seguras e permissões explícitas; ferramentas externas opcionais com validação, timeout e sem elevação silenciosa. Nunca classifique estado como saudável na ausência de dados.
- Sensor polling com intervalos, cancelamento, limites de memória e sem travar thread UI; registrar fonte, unidade, timestamp e qualidade da medição.

**Aceite:** leituras reais ou `indisponível`; mocks/fixtures; comportamento correto sem privilégios e com hardware ausente.

## FASE 4 — Benchmarks RAM/disco/rede e relatórios

- Revise `MemoryBench.cs`, `DiskBench.cs`, `NetworkTest.cs` e `ReportBuilder.cs` para separar a lógica reaproveitável.
- Para disco, registre diferenças entre `FILE_FLAG_NO_BUFFERING` Windows, Linux `O_DIRECT`, alinhamento, cache do SO, filesystem e armazenamento. Só adote `O_DIRECT` se houver implementação correta/validada; caso contrário rotule explicitamente `com cache` e não compare scores ao original.
- Limites de arquivo/tamanho/tempo e espaço livre; sem gravação direta em dispositivos; limpeza robusta e confirmação clara ao iniciar benchmark.
- Testes de rede somente opt-in, documentando tráfego e endpoints; modo diagnóstico local não deve conectar à internet.
- Exportação HTML escapando entradas e JSON versionado com tratamento de privacidade; respeite XDG Base Directory quando fizer sentido.

## FASE 5 — GPU, Vulkan e overlay (somente após a base estável)

- Estude o pipeline original de `GpuGameBench.cs` (D3D11), `GpuRtBench.cs` (DXR/D3D12) e `FrameMonitor.cs` (ETW); estabeleça comparação do workload antes de construir Vulkan.
- Prototipe Vulkan para rasterização e, separadamente, ray tracing se extensões e hardware forem compatíveis. Documente diferenças e NÃO reutilize pontuações do Windows sem validação. Não habilite stress GPU por padrão.
- Para overlay/FPS, pesquise mecanismos existentes para X11/Wayland, com permissões e limitações honestas; não alegue overlay universal ou hooks não implementados. Evite injeção em processos e bypass de anticheat.
- GPU sem backend/driver suportado deve apresentar mensagem de incompatibilidade, não travar nem falsificar FPS.

## FASE 6 — Extras e recursos sensíveis (postergar)

- Biblioteca de jogos e Steam/VDF com backups e validação de paths, sem modificar jogos por padrão.
- OpenRGB via serviço local explícito; integrações de terceiros opcionais, licenciadas e seguras.
- Drivers, inicialização, otimizações, controles de energia/clock/OC e Maker exigem desenho Linux independente, autorização granular e mecanismo de reversão. Começar como diagnósticos SOMENTE LEITURA; não equiparar o comportamento Windows ao Linux.
- Implementar somente após revisão de segurança, testes em distro real e opt-in explícito.

## FASE 7 — QA, distribuição e proposta à equipe RESET

- Matriz: Ubuntu/Debian, Fedora, uma distro Arch-based quando houver ambiente, AMD/Intel/NVIDIA se houver hardware, X11 e Wayland; documentar casos sem teste.
- CI Linux para Core/backend/CLI/UI build, testes unitários e análise estática; CI Windows para preservar app WPF original. Smoke tests e benchmarks não destrutivos exclusivamente opt-in. Sem release automática por padrão.
- `dotnet publish` por RID `linux-x64` e, depois, considerar outros RIDs; documentar dependências nativas e empacotamentos AppImage/.deb/.rpm conforme validação. Evitar prometer portabilidade apenas com binário gerado.
- Segurança: análise de dependências, licença MIT e obrigações de terceiros, sanitização de dados no relatório, ausência de sudo implícito e estado explícito das funcionalidades não suportadas.
- Criar `docs/PROPOSTA-A-EQUIPE-RESET.md` com arquitetura, roadmap, tabela de reaproveitamento, testes executados, limitações e orientação de fork. Não preparar PR automaticamente porque o README do projeto diz que não aceita PRs.

## Método de execução no Codex

- **Nesta tarefa, execute Fase 0 e Fase 1 de verdade; não realize Fases 2–7 automaticamente.** Elas são o contrato de evolução para pedidos posteriores.
- Antes de editar: confira `git status`, branch/commit, ferramentas (`dotnet --info`), e faça mapa de decisões. Se a working tree tiver modificações do usuário, preserve-as e não as substitua.
- Produza um plano breve, inicie a auditoria e continue a implementação da primeira vertical slice sem esperar aprovação para cada arquivo de baixo risco. Pare apenas diante de ação destrutiva, instalação/execução privilegiada, custo externo, publicação, alterações de dados do usuário ou bloqueio real.
- Após cada grupo de mudanças: compile/teste, revise diff e corrija erros. Inclua fixtures e testes com dados reais simulados; não execute stress nos testes.
- Se internet/NuGet estiverem indisponíveis, implemente o máximo viável sem inventar build bem-sucedido; relate o bloqueio e comandos para validar depois. Não use binários vendorizados não verificados.
- Ao finalizar, devolva **somente resultados verificáveis**, em português, com:
  1. SHA/branch de base e resumo da auditoria com caminhos relevantes;
  2. arquitetura e arquivos adicionados/alterados;
  3. funcionalidades funcionando, parciais, indisponíveis e não testadas;
  4. comandos exatos para instalar dependências via métodos oficiais (sem executá-los automaticamente), compilar, testar e rodar CLI/UI no Linux;
  5. evidência de build/testes/erros, separados por Linux e Windows;
  6. riscos/licenças/questões de segurança;
  7. indicação objetiva da primeira tarefa para Fase 2;
  8. `git status` e diff resumido, sem push ou release.

**Comece agora lendo o repositório e implementando as Fases 0–1. Não entregue só um plano, não produza placeholders apresentados como recursos prontos e não faça uma reescrita total.**
